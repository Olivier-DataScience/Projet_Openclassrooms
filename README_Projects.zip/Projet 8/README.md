# Projet 8 – Réalisez un dashboard et assurez une veille technique

Conception d’un dashboard interactif pour visualiser le score crédit et le rendre compréhensible.

## Étapes principales :
- Création de maquettes utilisateur
- Implémentation Streamlit + FastAPI
- Intégration des visualisations SHAP et comparaisons
- Analyse des risques RGPD, biais et sécurité
