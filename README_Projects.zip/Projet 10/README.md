# Projet 10 – Réalisez le cadrage d’un projet IA

Élaboration complète du cadrage d’un projet IA mobile dans le secteur de la mode (Fashion-Insta).

## Étapes principales :
- Définition des objectifs, cibles, livrables
- Planification SCRUM, charges, budget Azure
- Analyse RGPD, risques et biais algorithmiques
- Présentation au COMEX avec support synthétique
